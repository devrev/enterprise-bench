#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

if [[ "${1:-}" == "-h" || "${1:-}" == "--help" ]]; then
  printf '%s\n' 'Usage: ./compose-down.sh [docker compose down options]'
  exit 0
fi

docker compose -f "$SCRIPT_DIR/docker-compose.yaml" down "$@"
