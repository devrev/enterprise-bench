"""Shared Google Drive-style search-query parser and evaluator.

One tokenizer/parser/evaluator used by BOTH the REST layer (``server.py``'s
``/drive/v3/files?q=``) and the MCP layer (``mcp_server.py``'s ``search_files``)
so their query behaviour is identical. The REST layer surfaces a parse failure
as HTTP 400; the MCP layer surfaces it as a structured error object. Neither
layer manufactures a filename match for an unrecognised clause or silently
returns an empty result for malformed syntax.

Scope and provenance of the supported dialect
----------------------------------------------
Only terms that are actually backed by this fixture's data are accepted:

  * ``name`` / ``title``      operators: ``contains``, ``=``, ``!=``
  * ``fullText``              operator:  ``contains`` (whole-token semantics)
  * ``mimeType``              operators: ``=``, ``!=``, ``contains``
  * ``parents`` / ``parentId`` ``'<id>' in parents`` or ``parentId = '<id>'``
  * ``trashed``               operator:  ``=`` with ``true`` / ``false``

``title`` is accepted as an alias of ``name`` and ``parentId`` as an alias of
``parents`` (the MCP tool surface speaks ``title``/``parentId``; the REST/Drive
v3 surface speaks ``name``/``parents``). The alias is resolved in the parser so
both layers evaluate one AST.

``and`` / ``or`` / ``not`` and parentheses grouping are supported, matching the
official Drive v3 search guide and the Drive MCP ``search_files`` reference.

Deliberate local limitations (documented, not silent):
  * ``trashed`` is NOT part of the official Drive MCP ``search_files`` contract;
    it is a Drive v3 REST term. We accept it as a *local compatibility
    extension*. The fixture has no trashed files, so ``trashed = false`` is a
    no-op over every entry and ``trashed = true`` matches nothing.
  * ``properties has`` / ``appProperties has`` always match nothing. This
    dataset intentionally exposes no custom properties (fairness), so there is
    nothing to match. This is a local limitation, surfaced as an empty result
    rather than an error, so an agent probing for gifted CRM linkage gets a
    fair no-match instead of a crash.
  * ``name``/``title contains`` matches at word prefixes, not arbitrary
    mid-word substrings, following Drive's documented prefix rule.
  * ``fullText contains`` uses whole-token matching, mirroring Drive's
    documented rule. A hyphenated query term (``TKT-73233``) stays atomic to
    avoid false ticket matches, while plain-word searches also find pieces of
    hyphenated words (e.g. ``renewal`` in ``non-renewal``). The official
    references do NOT specify how hyphens are tokenized; this is local policy.

Anything else — an unknown term (``owner``, ``modifiedTime``, ``starred`` …),
an unsupported operator for a term, a bare word with no operator, or malformed
grouping — raises :class:`QueryError`. We do not pretend to back Drive fields
(owner, visibility, timestamps, sorting) that have no source data here.
"""
from __future__ import annotations

import re
from typing import Callable, List, Optional


class QueryError(ValueError):
    """Raised for an unsupported, malformed, or empty-but-present query.

    ``message`` is a human-readable reason suitable for an HTTP 400 ``detail``
    or an MCP structured-error ``message``.
    """


# Term → canonical name after alias resolution.
_TERM_ALIASES = {
    "title": "name",
    "parentid": "parents",
}

# Canonical terms we actually back, mapped to the operators we honour.
_TERM_OPERATORS = {
    "name": {"contains", "=", "!="},
    "fulltext": {"contains"},
    "mimetype": {"=", "!=", "contains"},
    "trashed": {"="},
    # ``parents`` is only ever reached through the ``'<id>' in parents`` form or
    # the ``parentId = '<id>'`` alias, both normalised before operator checking.
    "parents": {"in", "=", "!="},
}

# ``properties has`` / ``appProperties has`` deliberately match nothing here.
_NOMATCH_TERMS = {"properties", "appproperties"}


# ---------------------------------------------------------------------------
# AST
# ---------------------------------------------------------------------------


class Node:
    def evaluate(self, entry, ctx: "EvalContext") -> bool:  # pragma: no cover
        raise NotImplementedError


class BoolOp(Node):
    def __init__(self, op: str, left: Node, right: Node):
        self.op = op  # "and" | "or"
        self.left = left
        self.right = right

    def evaluate(self, entry, ctx):
        if self.op == "and":
            return self.left.evaluate(entry, ctx) and self.right.evaluate(entry, ctx)
        return self.left.evaluate(entry, ctx) or self.right.evaluate(entry, ctx)


class NotOp(Node):
    def __init__(self, child: Node):
        self.child = child

    def evaluate(self, entry, ctx):
        return not self.child.evaluate(entry, ctx)


class Comparison(Node):
    """A single ``term operator value`` clause after alias resolution."""

    def __init__(self, term: str, operator: str, value: str):
        self.term = term          # canonical, lowercased
        self.operator = operator  # "contains" | "=" | "!=" | "in"
        self.value = value

    # -- individual term evaluators ----------------------------------------

    def _eval_name(self, name: str) -> bool:
        v = self.value.lower()
        n = name.lower()
        if self.operator == "contains":
            # Drive documents prefix rather than arbitrary substring matching.
            # Word-boundary prefixes preserve this replica's useful searches
            # across spaces/underscores (e.g. 'register' in 'maple_register.md')
            # without matching a suffix like 'gister'.
            return bool(v) and re.search(r"(?<![a-z0-9])" + re.escape(v), n) is not None
        if self.operator == "=":
            return n == v
        if self.operator == "!=":
            return n != v
        return False  # pragma: no cover - guarded at parse time

    def _eval_mime(self, mime: str) -> bool:
        if self.operator == "contains":
            return self.value.lower() in mime.lower()
        if self.operator == "=":
            return mime == self.value
        if self.operator == "!=":
            return mime != self.value
        return False  # pragma: no cover

    def _eval_fulltext(self, entry, ctx) -> bool:
        # Drive documents whole-token matching, but not hyphen tokenization.
        # Query compounds stay atomic even though indexed compounds expose
        # their plain-word pieces for broad searches.
        needle_tokens = _tokenize(self.value)
        if not needle_tokens:
            return False
        haystack = ctx.fulltext_tokens(entry)
        return all(tok in haystack for tok in needle_tokens)

    def _eval_trashed(self, ctx) -> bool:
        # Local compatibility extension: no fixture file is trashed.
        want = self.value.strip().lower()
        if want not in ("true", "false"):
            raise QueryError(
                "trashed must be compared to true or false, e.g. trashed = false"
            )
        return want == "false"  # every file is untrashed

    def _eval_parents(self, entry, ctx) -> bool:
        pid = self.value
        is_member = ctx.parent_of(entry) == pid
        if self.operator in ("in", "="):
            return is_member
        if self.operator == "!=":
            return not is_member
        return False  # pragma: no cover

    def evaluate(self, entry, ctx):
        if self.term in _NOMATCH_TERMS:
            return False
        if self.term == "name":
            return self._eval_name(ctx.name_of(entry))
        if self.term == "mimetype":
            return self._eval_mime(ctx.mime_of(entry))
        if self.term == "fulltext":
            return self._eval_fulltext(entry, ctx)
        if self.term == "trashed":
            return self._eval_trashed(ctx)
        if self.term == "parents":
            return self._eval_parents(entry, ctx)
        return False  # pragma: no cover - guarded at parse time


# ---------------------------------------------------------------------------
# Evaluation context — adapts arbitrary entry objects to the evaluator.
# ---------------------------------------------------------------------------


class EvalContext:
    """Bridges entry objects (FileEntry / FolderView dicts) to the evaluator.

    Callers supply accessors so the parser stays independent of the concrete
    entry representation. ``fulltext_reader`` returns the file's text (or None)
    and is tokenised+cached here per evaluation pass.
    """

    def __init__(
        self,
        name_of: Callable[[object], str],
        mime_of: Callable[[object], str],
        parent_of: Callable[[object], str],
        fulltext_reader: Callable[[object], Optional[str]],
    ):
        self.name_of = name_of
        self.mime_of = mime_of
        self.parent_of = parent_of
        self._fulltext_reader = fulltext_reader
        self._token_cache: dict = {}

    def fulltext_tokens(self, entry) -> set:
        key = id(entry)
        cached = self._token_cache.get(key)
        if cached is not None:
            return cached
        # fullText covers name + content (Drive indexes name, description and body).
        text = self.name_of(entry) or ""
        body = self._fulltext_reader(entry)
        if body:
            text = f"{text}\n{body}"
        tokens = _tokenize(text, index_hyphen_parts=True)
        self._token_cache[key] = tokens
        return tokens


def _tokenize(text: str, *, index_hyphen_parts: bool = False) -> set:
    """Keep compound query terms atomic; index their pieces for plain-word search.

    A query for TKT-001 requires that exact compound token, never separate TKT
    and 001 occurrences. An indexed non-renewal also contributes the plain word
    renewal, so a user searching renewal can still discover the document.
    Drive documents whole-token matching, but not its hyphen boundaries; this
    query-aware behavior is a local correctness choice.
    """
    tokens = {
        match.group(0).lower()
        for match in re.finditer(r"[A-Za-z0-9]+(?:-[A-Za-z0-9]+)*", text)
    }
    if index_hyphen_parts:
        tokens.update(
            piece
            for token in tuple(tokens)
            if "-" in token
            for piece in token.split("-")
        )
    return tokens


# ---------------------------------------------------------------------------
# Tokenizer
# ---------------------------------------------------------------------------

_TOKEN_RE = re.compile(
    r"""
      \s+                             # whitespace (skipped)
    | (?P<lparen>\() | (?P<rparen>\))
    | (?P<lbrace>\{) | (?P<rbrace>\})
    | (?P<neq>!=) | (?P<eq>=)
    | (?P<str>'(?:\\'|[^'])*')        # single-quoted string (with \' escapes)
    | (?P<word>[A-Za-z_][A-Za-z0-9_.-]*)  # bare identifier / keyword (hyphens ok)
    """,
    re.VERBOSE,
)


class _Tok:
    def __init__(self, kind: str, value: str, pos: int):
        self.kind = kind
        self.value = value
        self.pos = pos


def _lex(q: str) -> List[_Tok]:
    toks: List[_Tok] = []
    i = 0
    n = len(q)
    while i < n:
        m = _TOKEN_RE.match(q, i)
        if not m or m.end() == i:
            raise QueryError(f"Unexpected character at position {i}: {q[i]!r}")
        i = m.end()
        kind = m.lastgroup
        if kind is None:
            continue  # whitespace
        toks.append(_Tok(kind, m.group(), m.start()))
    return toks


# ---------------------------------------------------------------------------
# Recursive-descent parser
#   expr   := or_expr
#   or_expr  := and_expr ( 'or' and_expr )*
#   and_expr := unary ( 'and' unary )*
#   unary    := 'not' unary | primary
#   primary  := '(' expr ')' | comparison
# ---------------------------------------------------------------------------

_KEYWORDS = {"and", "or", "not", "in", "contains", "has"}


class _Parser:
    def __init__(self, toks: List[_Tok]):
        self.toks = toks
        self.i = 0

    def _peek(self) -> Optional[_Tok]:
        return self.toks[self.i] if self.i < len(self.toks) else None

    def _next(self) -> _Tok:
        tok = self.toks[self.i]
        self.i += 1
        return tok

    def _is_word(self, tok: Optional[_Tok], word: str) -> bool:
        return tok is not None and tok.kind == "word" and tok.value.lower() == word

    def parse(self) -> Node:
        if not self.toks:
            raise QueryError("Empty query.")
        node = self._or_expr()
        if self.i != len(self.toks):
            extra = self.toks[self.i]
            raise QueryError(f"Unexpected token near position {extra.pos}: {extra.value!r}")
        return node

    def _or_expr(self) -> Node:
        node = self._and_expr()
        while self._is_word(self._peek(), "or"):
            self._next()
            right = self._and_expr()
            node = BoolOp("or", node, right)
        return node

    def _and_expr(self) -> Node:
        node = self._unary()
        while self._is_word(self._peek(), "and"):
            self._next()
            right = self._unary()
            node = BoolOp("and", node, right)
        return node

    def _unary(self) -> Node:
        if self._is_word(self._peek(), "not"):
            self._next()
            return NotOp(self._unary())
        return self._primary()

    def _primary(self) -> Node:
        tok = self._peek()
        if tok is None:
            raise QueryError("Unexpected end of query; expected a clause.")
        if tok.kind == "lparen":
            self._next()
            node = self._or_expr()
            closing = self._peek()
            if closing is None or closing.kind != "rparen":
                raise QueryError("Unmatched '(' — missing closing parenthesis.")
            self._next()
            return node
        if tok.kind == "rparen":
            raise QueryError(f"Unexpected ')' at position {tok.pos}.")
        return self._comparison()

    def _comparison(self) -> Node:
        tok = self._next()
        if tok.kind == "str":
            # Only valid lead for a string literal is the `'<id>' in parents` form.
            value = _unquote(tok.value)
            nxt = self._peek()
            if self._is_word(nxt, "in"):
                self._next()
                parents = self._peek()
                if not self._is_word(parents, "parents"):
                    raise QueryError(
                        "Expected 'in parents' after a quoted id, "
                        "e.g. '<id>' in parents."
                    )
                self._next()
                return Comparison("parents", "in", value)
            raise QueryError(
                f"Bare value {tok.value!r} is not a valid clause. "
                "Use a term, e.g. fullText contains 'TKT-73233' or "
                "'<folder-id>' in parents."
            )
        if tok.kind != "word":
            raise QueryError(f"Expected a query term but found {tok.value!r}.")

        raw_term = tok.value.lower()
        if raw_term in _KEYWORDS:
            raise QueryError(f"Unexpected operator {tok.value!r}; expected a query term.")

        term = _TERM_ALIASES.get(raw_term, raw_term)

        # properties has / appProperties has — documented local no-match.
        if term in _NOMATCH_TERMS:
            op = self._peek()
            if not self._is_word(op, "has"):
                raise QueryError(
                    f"{tok.value} only supports the 'has' operator here, "
                    "and always returns no matches in this dataset."
                )
            self._next()
            # consume the brace/value expression loosely: Drive uses
            # `properties has { key='k' and value='v' }`. We accept any
            # remaining balanced-ish tokens up to the next boolean keyword.
            self._consume_properties_body()
            return Comparison(term, "has", "")

        if term not in _TERM_OPERATORS:
            raise QueryError(
                f"Unsupported query term {tok.value!r}. Supported terms: "
                "name/title, fullText, mimeType, parents/parentId, trashed."
            )

        op_tok = self._peek()
        if op_tok is None:
            raise QueryError(
                f"Term {tok.value!r} is missing an operator and value."
            )

        # Resolve operator token.
        if op_tok.kind in ("eq", "neq"):
            operator = "=" if op_tok.kind == "eq" else "!="
            self._next()
        elif self._is_word(op_tok, "contains"):
            operator = "contains"
            self._next()
        elif self._is_word(op_tok, "in"):
            operator = "in"
            self._next()
        else:
            raise QueryError(
                f"Unsupported or missing operator after {tok.value!r}: "
                f"found {op_tok.value!r}."
            )

        if operator not in _TERM_OPERATORS[term]:
            raise QueryError(
                f"Operator {operator!r} is not supported for term {tok.value!r}."
            )

        # Value.
        val_tok = self._peek()
        if val_tok is None:
            raise QueryError(f"Missing value after {tok.value} {operator}.")

        if term == "trashed":
            # trashed = true/false — value is a bare boolean word.
            if val_tok.kind == "word" and val_tok.value.lower() in ("true", "false"):
                self._next()
                return Comparison("trashed", "=", val_tok.value.lower())
            raise QueryError("trashed must be compared to true or false.")

        if val_tok.kind == "str":
            self._next()
            return Comparison(term, operator, _unquote(val_tok.value))

        raise QueryError(
            f"Value after {tok.value} {operator} must be single-quoted, "
            f"e.g. {tok.value} {operator} 'value'."
        )

    def _consume_properties_body(self) -> None:
        """Loosely skip a properties body if present.

        We do not interpret it — ``properties has`` always yields no matches in
        this dataset — but we tolerate the official brace form
        ``properties has { key='k' and value='v' }`` as well as a bare quoted
        value, instead of calling it malformed.
        """
        tok = self._peek()
        if tok is None:
            return
        if tok.kind == "lbrace":
            # Skip a balanced { ... } block.
            depth = 0
            while self._peek() is not None:
                t = self._next()
                if t.kind == "lbrace":
                    depth += 1
                elif t.kind == "rbrace":
                    depth -= 1
                    if depth == 0:
                        return
            raise QueryError("Unmatched '{' in properties expression.")
        if tok.kind in ("str", "word") and tok.value.lower() not in _KEYWORDS:
            # Bare trailing value form: consume a single token.
            self._next()


def _unquote(s: str) -> str:
    if len(s) >= 2 and s[0] == "'" and s[-1] == "'":
        inner = s[1:-1]
        return inner.replace("\\'", "'")
    return s


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def parse_query(q: str) -> Node:
    """Parse a Drive-style query string into an evaluatable AST.

    Raises :class:`QueryError` for empty, unsupported, or malformed queries.
    """
    if q is None:
        raise QueryError("Empty query.")
    if not q.strip():
        raise QueryError("Empty query.")
    toks = _lex(q)
    return _Parser(toks).parse()


def evaluate(node: Node, entries: list, ctx: EvalContext) -> list:
    """Return entries for which ``node`` evaluates true, preserving order."""
    return [e for e in entries if node.evaluate(e, ctx)]


def wants_folders(node: Node) -> bool:
    """True if the query references the folder mimeType anywhere.

    Lets a caller widen the search space to include folder objects, matching
    the pre-existing folder-listing behaviour.
    """
    folder_mime = "application/vnd.google-apps.folder"

    def walk(n: Node) -> bool:
        if isinstance(n, BoolOp):
            return walk(n.left) or walk(n.right)
        if isinstance(n, NotOp):
            return walk(n.child)
        if isinstance(n, Comparison):
            return n.term == "mimetype" and folder_mime in n.value
        return False

    return walk(node)
