"""Tests for the MCP Host and Origin guard."""

import sys
import unittest
from pathlib import Path
from unittest.mock import Mock

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from mcp_security import HostOriginGuard, run_mcp  # noqa: E402


class HostOriginGuardTests(unittest.IsolatedAsyncioTestCase):
    async def check_request(self, headers: list[tuple[bytes, bytes]]) -> int:
        messages = []

        async def app(scope, receive, send):
            await send({"type": "http.response.start", "status": 204, "headers": []})
            await send({"type": "http.response.body", "body": b""})

        async def receive():
            return {"type": "http.request", "body": b""}

        async def send(message):
            messages.append(message)

        guard = HostOriginGuard(app, 8011, "pm-mcp")
        await guard({"type": "http", "headers": headers}, receive, send)
        return messages[0]["status"]

    async def test_allowed_hosts_and_same_origin(self) -> None:
        for host in (
            b"localhost:8011",
            b"127.0.0.1:8011",
            b"[::1]:8011",
            b"host.docker.internal:8011",
            b"pm-mcp:8011",
        ):
            with self.subTest(host=host):
                self.assertEqual(await self.check_request([(b"host", host)]), 204)
                self.assertEqual(
                    await self.check_request(
                        [
                            (b"host", host),
                            (b"origin", b"http://" + host),
                        ]
                    ),
                    204,
                )

    async def test_invalid_and_duplicate_hosts_and_origins(self) -> None:
        self.assertEqual(await self.check_request([]), 421)
        self.assertEqual(await self.check_request([(b"host", b"evil.example:8011")]), 421)
        self.assertEqual(
            await self.check_request(
                [
                    (b"host", b"localhost:8011"),
                    (b"host", b"evil.example"),
                ]
            ),
            421,
        )
        self.assertEqual(
            await self.check_request(
                [
                    (b"host", b"localhost:8011"),
                    (b"origin", b"https://evil.example"),
                ]
            ),
            403,
        )
        self.assertEqual(
            await self.check_request(
                [
                    (b"host", b"localhost:8011"),
                    (b"origin", b"http://localhost:8012"),
                ]
            ),
            403,
        )
        self.assertEqual(
            await self.check_request(
                [
                    (b"host", b"localhost:8011"),
                    (b"origin", b"http://localhost:8011"),
                    (b"origin", b"https://evil.example"),
                ]
            ),
            403,
        )

    def test_run_uses_the_guard(self) -> None:
        server = Mock()
        run_mcp(server, 8011, "pm-mcp")
        kwargs = server.run.call_args.kwargs
        self.assertEqual(kwargs["port"], 8011)
        middleware = kwargs["middleware"][0]
        self.assertIs(middleware.cls, HostOriginGuard)
        self.assertEqual(middleware.kwargs, {"port": 8011, "service_host": "pm-mcp"})
