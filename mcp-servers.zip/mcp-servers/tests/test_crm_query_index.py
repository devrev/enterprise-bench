"""Small regression tests for query-scoped CRM relationship indexing."""
import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "crm"))
import server as core
from soql_engine import _QUERY_CHILD_BUCKETS, _QUERY_INDEXES, execute_soql, parse_soql


class RelationshipIndexTests(unittest.TestCase):
    def setUp(self):
        self.original = dict(core.DATA_STORE)
        core.DATA_STORE.clear()
        core.DATA_STORE.update({
            "Account": [
                {"account_id": "A1", "account_name": "First"},
                {"account_id": "A1", "account_name": "Duplicate"},
                {"account_id": "A2", "account_name": "No children"},
            ],
            "Opportunity": [
                {"opportunity_id": "O1", "account_id": "A1"},
                {"opportunity_id": "O2", "account_id": "missing"},
            ],
            "User": [],
        })

    def tearDown(self):
        core.DATA_STORE.clear()
        core.DATA_STORE.update(self.original)

    def test_first_duplicate_and_missing_parent_match_linear_scan(self):
        records = execute_soql(parse_soql("SELECT Id, Account.Name FROM Opportunity"))["records"]
        self.assertEqual([row["Account"]["Name"] for row in records], ["First", None])
        self.assertIsNone(_QUERY_INDEXES.get())

    def test_index_is_rebuilt_for_each_query(self):
        query = parse_soql("SELECT Account.Name FROM Opportunity LIMIT 1")
        self.assertEqual(execute_soql(query)["records"][0]["Account"]["Name"], "First")
        core.DATA_STORE["Account"][0]["account_name"] = "Updated"
        self.assertEqual(execute_soql(parse_soql("SELECT Account.Name FROM Opportunity LIMIT 1"))["records"][0]["Account"]["Name"], "Updated")
        self.assertIsNone(_QUERY_INDEXES.get())

    def test_query_context_resets_after_error(self):
        with self.assertRaises(ValueError):
            execute_soql(parse_soql("SELECT Account.NoSuchField FROM Opportunity LIMIT 1"))
        self.assertIsNone(_QUERY_INDEXES.get())
        self.assertIsNone(_QUERY_CHILD_BUCKETS.get())

    def test_child_bucket_preserves_order_and_null_empty_relationship(self):
        query = "SELECT Id, (SELECT Id FROM Opportunities LIMIT 1) FROM Account"
        records = execute_soql(parse_soql(query))["records"]
        self.assertEqual([row["Opportunities"]["records"][0]["Id"] for row in records[:2]], ["O1", "O1"])
        self.assertIsNone(records[2]["Opportunities"])
        self.assertIsNone(_QUERY_CHILD_BUCKETS.get())


if __name__ == "__main__":
    unittest.main()
