"""Tests for the standalone, MCP-only Compose stack (no containers required)."""

import json
import os
import shutil
import subprocess
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


class ComposeTests(unittest.TestCase):
    @unittest.skipUnless(shutil.which("docker"), "Docker CLI is not installed")
    def test_config_has_only_six_mcp_services(self) -> None:
        result = subprocess.run(
            [
                "docker",
                "compose",
                "-f",
                str(ROOT / "docker-compose.yaml"),
                "config",
                "--format",
                "json",
            ],
            capture_output=True,
            check=True,
            text=True,
        )
        services = json.loads(result.stdout)["services"]
        expected = {
            "pm-mcp": ("pm", 8011),
            "crm-mcp": ("crm", 8012),
            "file-server-mcp": ("file-server", 8013),
            "cs-mcp": ("cs", 8014),
            "email-mcp": ("mail-server", 8015),
            "calendar-mcp": ("calendar-server", 8016),
        }
        self.assertEqual(set(services), set(expected))
        for service, (directory, port) in expected.items():
            config = services[service]
            self.assertEqual(Path(config["build"]["context"]), ROOT)
            self.assertEqual(config["build"]["dockerfile"], f"{directory}/Dockerfile")
            self.assertEqual(config["environment"]["MCP_PORT"], str(port))
            self.assertEqual(config["ports"][0]["target"], port)
            self.assertEqual(config["ports"][0]["host_ip"], "127.0.0.1")
            self.assertNotIn("depends_on", config)
            self.assertTrue(all(mount["read_only"] for mount in config["volumes"]))
            dockerfile = (ROOT / directory / "Dockerfile").read_text()
            self.assertIn('CMD ["python", "mcp_server.py"]', dockerfile)
            self.assertIn("COPY mcp_security.py .", dockerfile)
            self.assertIn(
                f'run_mcp(mcp, MCP_PORT, "{service}")',
                (ROOT / directory / "mcp_server.py").read_text(),
            )

    def test_up_checks_data_and_passes_canonical_paths_to_compose(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            work = Path(tmp).resolve()
            data = work / "data with spaces"
            for directory in (
                "crm_json_data",
                "pm_json_data",
                "maple_kb",
                "internal_docs",
                "transcripts",
                "drive",
                "cs_json_data",
                "email_json_data",
                "calendar_json_data",
            ):
                (data / directory).mkdir(parents=True)
            (data / "drive" / "drive-manifest.json").write_text("{}")

            bindir = work / "bin"
            bindir.mkdir()
            docker = bindir / "docker"
            docker.write_text(
                '#!/bin/sh\nprintf "ARG=%s\\n" "$@"\n'
                'printf "CRM=%s\\nPM=%s\\nKB=%s\\n" '
                '"$CRM_DATA_PATH" "$PM_DATA_PATH" "$MAPLE_KB_PATH"\n'
            )
            docker.chmod(0o755)
            env = {
                key: value
                for key, value in os.environ.items()
                if key
                not in {
                    "CRM_DATA_PATH",
                    "PM_DATA_PATH",
                    "FILE_DATA_PATH",
                    "CS_DATA_PATH",
                    "MAIL_DATA_PATH",
                    "CALENDAR_DATA_PATH",
                    "MAPLE_KB_PATH",
                    "SCALE",
                }
            }
            env.update({"PATH": f"{bindir}{os.pathsep}{env['PATH']}", "DATA_PATH": data.name})
            result = subprocess.run(
                [str(ROOT / "compose-up.sh"), "--build"],
                cwd=work,
                env=env,
                capture_output=True,
                check=True,
                text=True,
            )
            self.assertIn("ARG=up\nARG=-d\nARG=--build\n", result.stdout)
            self.assertIn(f"CRM={data}\nPM={data}\nKB={data / 'maple_kb'}\n", result.stdout)

            (data / "drive" / "drive-manifest.json").unlink()
            missing = subprocess.run(
                [str(ROOT / "compose-up.sh")],
                cwd=work,
                env=env,
                capture_output=True,
                text=True,
            )
            self.assertEqual(missing.returncode, 2)
            self.assertIn("Drive manifest does not exist", missing.stderr)
            self.assertNotIn("ARG=up", missing.stdout)


if __name__ == "__main__":
    unittest.main()
