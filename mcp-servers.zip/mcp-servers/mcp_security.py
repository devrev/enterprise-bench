"""Host and Origin protection for both FastMCP 2.x and 3.x HTTP servers."""

from collections.abc import Awaitable, Callable, MutableMapping
from typing import Any

from starlette.middleware import Middleware

ASGIApp = Callable[
    [MutableMapping[str, Any], Callable[..., Awaitable[Any]], Callable[..., Awaitable[Any]]],
    Awaitable[None],
]


class HostOriginGuard:
    """Allow local and Compose service hosts, rejecting cross-origin requests."""

    def __init__(self, app: ASGIApp, port: int, service_host: str) -> None:
        self.app = app
        names = {"localhost", "127.0.0.1", "[::1]", "host.docker.internal", service_host}
        self.allowed_hosts = names | {f"{name}:{port}" for name in names}

    async def __call__(
        self,
        scope: MutableMapping[str, Any],
        receive: Callable[..., Awaitable[Any]],
        send: Callable[..., Awaitable[Any]],
    ) -> None:
        if scope["type"] != "http":
            await self.app(scope, receive, send)
            return

        hosts = [value for key, value in scope["headers"] if key.lower() == b"host"]
        origins = [value for key, value in scope["headers"] if key.lower() == b"origin"]
        try:
            host = hosts[0].decode("ascii").lower() if len(hosts) == 1 else ""
            origin = origins[0].decode("ascii").lower() if len(origins) == 1 else ""
        except UnicodeDecodeError:
            host, origin = "", ""

        if host not in self.allowed_hosts:
            status, message = 421, b"Invalid Host header"
        elif len(origins) > 1 or (origins and origin not in {f"http://{host}", f"https://{host}"}):
            status, message = 403, b"Invalid Origin header"
        else:
            await self.app(scope, receive, send)
            return

        await send({"type": "http.response.start", "status": status, "headers": []})
        await send({"type": "http.response.body", "body": message})


def run_mcp(mcp: Any, port: int, service_host: str) -> None:
    """Start the existing MCP implementation with transport security enabled."""
    mcp.run(
        transport="http",
        host="0.0.0.0",
        port=port,
        middleware=[Middleware(HostOriginGuard, port=port, service_host=service_host)],
    )
