#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
COMPOSE_FILE="$SCRIPT_DIR/docker-compose.yaml"

# Usage:
#   ./compose-down.sh                 -> docker compose down
#   ./compose-down.sh --rmi all       -> docker compose down --rmi all
#   ./compose-down.sh -v --remove-orphans
echo "Stopping MCP servers"
docker compose -f "$COMPOSE_FILE" down "$@"
