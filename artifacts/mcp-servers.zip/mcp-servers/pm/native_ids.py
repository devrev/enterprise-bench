"""Deterministic, opaque native key/id rewrite for the v2 PM server.

Enterprise-Bench v2 models the realistic enterprise pattern: the PM system
assigns its OWN identifiers on import — a project-scoped issue key (``MPL-…``),
an internal numeric id, and internal account ids for its own users — while the
migrated source IDs (``ISS-xxx`` / ``USER-xxx``) are kept as durable
cross-system correlation keys. The source issue ID is preserved on each issue in
``external_id`` (exposed to JQL as ``external_id`` and rendered as the
``customfield_10001`` import-map field). Each PM user keeps its source ID in the
user's own ``external_id``.

STRINGENT identity requirements (this module is deliberately stronger than a
suffix rewrite):

* Opaque, NON-suffix / NON-sequence-derived keys. The MPL key body and the
  internal numeric id are salted SHA-256 digests of the source ID, not its
  trailing digits or its position in the load order. ``ISS-017`` does NOT map to
  ``MPL-17``; there is no numeric-suffix or ordinal shortcut from source to
  native. Type/version are fixed by ``PM_NATIVE_ID_FORMAT`` and the salts below.

* Determinism / "delete-the-RNG" determinism rule (native-ID hardening design §3.1): the native key,
  internal id, and user account id are PURE deterministic functions of the
  source ID. No randomness, no seeded state, no serve-time sampling, no
  dependency on dict/order or the process. Same source ID -> same native ID on
  every run and every process, so answer keys and cross-system joins reproduce.

* Atomic, consistent relationship rewrite. Every PM-internal user reference
  (issue assignee/reporter/creator/modified-by and comment author) is rewritten
  to the referenced user's native account id in the SAME pass, so the served PM
  graph is self-consistent in native id-space. Cross-system fields — component /
  part ids and conversation ids — are NOT rewritten; they stay source
  identities (the ``ISS``/``USER`` source strings remain discoverable via the
  preserved external ids).

* Fail loud. Missing source ids and native key / internal-id / user-id
  collisions raise during load rather than silently corrupting a join. (A
  reference to a user PM does not own is NOT dangling — PM's served user table
  is a subset of the wider user namespace, so such references stay source
  identities like part ids and conversation ids.)

* No source-ID lookup fallback. After the rewrite the ISSUES store is keyed by
  the native MPL key ONLY; the source ``ISS-xxx`` is not a lookup key. Callers
  that need to resolve a source ID must query the ``external_id`` /
  ``customfield_10001`` field (see ``jql_engine``), exactly like the real PM API.
"""

from __future__ import annotations

import hashlib

# PM project the synthetic issues belong to (matches server.PROJECT["key"]).
PROJECT_KEY = "MPL"

# Custom field id that holds the migrated source ID in the PM issue shape.
IMPORT_MAP_CUSTOM_FIELD = "customfield_10001"

# Where each owned record preserves its source string ID.
EXTERNAL_ID_FIELD = "external_id"

# Format/version + salts. Changing any of these changes PM infrastructure
# identity and requires recomputing any frozen answer key expressed in native
# PM ids. They are format constants, not credentials.
PM_NATIVE_ID_FORMAT = "pm-v2-native-id-v1"
_KEY_SALT = "enterprise-bench-pm-native-key-v1"
_INTERNAL_ID_SALT = "enterprise-bench-pm-native-internal-id-v1"
_USER_ID_SALT = "enterprise-bench-pm-native-user-id-v1"

# Opaque body widths. The key body and the internal id draw from independent
# digests and disjoint numeric bands so neither can be derived from the other.
# The spaces are sized so the full 256x issue population (and headroom for noise
# growth) mints collision-free; the fail-loud guards below still catch any
# collision if the population ever outgrows the space.
_KEY_BODY_WIDTH = 8            # MPL-<8 digits>, e.g. MPL-41830572
_INTERNAL_ID_BAND = 10 ** 10   # internal ids land in [10^10, 2*10^10) (11-digit)

# PM-internal user reference fields on issues (source USER-xxx -> native id).
_ISSUE_USER_REFS = ("assignee_id", "reporter_id", "creator_id", "modified_by_id")
# PM-internal user reference field on comments.
_COMMENT_USER_REF = "author_id"


def _digest_int(salt: str, source_id: str, nbytes: int = 12) -> int:
    return int.from_bytes(
        hashlib.sha256(f"{salt}|{source_id}".encode("utf-8")).digest()[:nbytes],
        "big",
    )


def mint_key(source_id: str) -> str:
    """Deterministically mint the opaque project-scoped key (e.g. MPL-418305).

    The body is a salted SHA-256 digest of the source id, NOT its numeric tail
    or load position. Pure function of ``source_id``.
    """
    if not isinstance(source_id, str) or not source_id:
        raise ValueError("cannot mint PM key for empty source id")
    body = _digest_int(_KEY_SALT, source_id) % (10 ** _KEY_BODY_WIDTH)
    return f"{PROJECT_KEY}-{body:0{_KEY_BODY_WIDTH}d}"


def mint_internal_id(source_id: str) -> str:
    """Deterministically mint the opaque internal numeric id as a string.

    Drawn from a distinct salt and numeric band than the key body, so the
    internal id is not recoverable from the key (and vice versa). Pure function.
    """
    if not isinstance(source_id, str) or not source_id:
        raise ValueError("cannot mint PM internal id for empty source id")
    body = _digest_int(_INTERNAL_ID_SALT, source_id) % _INTERNAL_ID_BAND
    return str(_INTERNAL_ID_BAND + body)  # keeps a fixed width, no leading zeros


def mint_user_id(source_id: str) -> str:
    """Deterministically mint an opaque account id for a PM user.

    PM account ids are opaque 24-hex strings; we mint a stable one from the
    source USER id. Pure function of ``source_id``.
    """
    if not isinstance(source_id, str) or not source_id:
        raise ValueError("cannot mint PM user id for empty source id")
    return hashlib.sha256(f"{_USER_ID_SALT}|{source_id}".encode("utf-8")).hexdigest()[:24]


def _build_user_map(users: dict[str, dict]) -> dict[str, str]:
    """source USER id -> native account id, keyed idempotently off external_id.

    Fails loudly on a native account-id collision.
    """
    mapping: dict[str, str] = {}
    seen_native: dict[str, str] = {}
    for current_id, user in users.items():
        source_id = user.get(EXTERNAL_ID_FIELD, user.get("user_id", current_id))
        native = mint_user_id(source_id)
        if native in seen_native and seen_native[native] != source_id:
            raise ValueError(
                f"native PM user-id collision {native!r}: "
                f"{seen_native[native]} and {source_id}"
            )
        seen_native[native] = source_id
        mapping[source_id] = native
    return mapping


def rewrite_user_ids(users: dict[str, dict]) -> dict[str, str]:
    """Rewrite the USERS store in place to native account ids + external ids.

    Each user gains ``external_id`` (the source USER-xxx) and its ``user_id`` is
    replaced by the native account id. The store is re-keyed by the native id.
    Returns the source->native map. Idempotent.
    """
    mapping = _build_user_map(users)
    rebuilt: dict[str, dict] = {}
    for current_id, user in list(users.items()):
        if EXTERNAL_ID_FIELD in user:
            rebuilt[user["user_id"]] = user
            continue
        source_id = user.get("user_id", current_id)
        user[EXTERNAL_ID_FIELD] = source_id
        user["user_id"] = mapping[source_id]
        rebuilt[user["user_id"]] = user
    users.clear()
    users.update(rebuilt)
    return mapping


def _rewrite_user_ref(record: dict, field: str, user_map: dict[str, str]) -> None:
    """Rewrite one user reference on a record to its native id, in place.

    Only references to PM-OWNED users (present in ``user_map``) are rewritten;
    the served PM user table is a subset of the wider user namespace, so a
    reference to a user PM does not own stays a source identity — the same
    treatment given to component/part ids and conversation ids. Idempotent:
    values already native pass through unchanged.
    """
    value = record.get(field)
    if value in (None, ""):
        return
    if value in user_map:
        record[field] = user_map[value]
        return
    # else: already native, or a reference to a non-PM-owned user — leave as the
    # source identity so cross-system joins on the source user id still resolve.


def rewrite_issue_ids(
    issues: dict[str, dict],
    users: dict[str, str] | dict[str, dict] | None = None,
    comments: dict[str, list] | None = None,
) -> dict[str, dict]:
    """Rewrite the ISSUES store in place to the native key/id + import-map model.

    Each issue gains ``pm_key`` (opaque MPL key), ``pm_internal_id`` (opaque
    numeric), and ``external_id`` (the source ISS-xxx). The store is re-keyed by
    the native ``pm_key`` so record lookup uses the native key ONLY, mirroring
    the real PM API. PM-internal user references on issues (and on comments, when a
    comments store is supplied) are rewritten to native user account ids using
    ``user_map``. Component/part ids and conversation ids are intentionally left
    as source identities.

    ``users`` may be either the already-built source->native user map (a
    ``dict[str, str]``) or the USERS store itself (a ``dict[str, dict]``), in
    which case the map is derived. Returns the rebuilt ISSUES store. Idempotent:
    issues already carrying ``external_id`` are left untouched.

    Fail-loud: missing source ids, native key/internal-id collisions, and
    dangling user references raise here.
    """
    user_map = _coerce_user_map(users)

    rebuilt: dict[str, dict] = {}
    seen_key: dict[str, str] = {}
    seen_internal: dict[str, str] = {}
    for current_key, issue in issues.items():
        if EXTERNAL_ID_FIELD in issue:
            native_key = issue.get("pm_key", current_key)
            rebuilt[native_key] = issue
            continue
        source_id = issue.get("issue_id", current_key)
        if not source_id:
            raise ValueError(f"PM issue {current_key!r} is missing a source id")
        native_key = mint_key(source_id)
        internal_id = mint_internal_id(source_id)

        if native_key in seen_key and seen_key[native_key] != source_id:
            raise ValueError(
                f"native PM key collision {native_key!r}: "
                f"{seen_key[native_key]} and {source_id}"
            )
        if internal_id in seen_internal and seen_internal[internal_id] != source_id:
            raise ValueError(
                f"native PM internal-id collision {internal_id!r}: "
                f"{seen_internal[internal_id]} and {source_id}"
            )
        seen_key[native_key] = source_id
        seen_internal[internal_id] = source_id

        issue[EXTERNAL_ID_FIELD] = source_id
        issue["pm_key"] = native_key
        issue["pm_internal_id"] = internal_id

        # Atomically rewrite this issue's PM-internal user references.
        if user_map:
            for field in _ISSUE_USER_REFS:
                _rewrite_user_ref(issue, field, user_map)

        rebuilt[native_key] = issue

    issues.clear()
    issues.update(rebuilt)

    # Rewrite comment authors in the same consistent pass.
    if comments and user_map:
        for thread in comments.values():
            for comment in thread:
                _rewrite_user_ref(comment, _COMMENT_USER_REF, user_map)

    return issues


def _coerce_user_map(users) -> dict[str, str]:
    """Accept either a prebuilt source->native map or the USERS store."""
    if not users:
        return {}
    sample = next(iter(users.values()))
    if isinstance(sample, dict):
        # USERS store: each user already rewritten (external_id -> native user_id).
        out: dict[str, str] = {}
        for user in users.values():
            source = user.get(EXTERNAL_ID_FIELD)
            native = user.get("user_id")
            if source and native:
                out[source] = native
        return out
    return dict(users)  # already a source->native map
