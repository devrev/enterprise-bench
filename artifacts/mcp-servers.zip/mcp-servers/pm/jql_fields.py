"""Typed JQL field registry for PM MCP v1.1.

Centralizes the operator/type policy that used to live as ad-hoc sets
(``VALID_QUERY_FIELDS``, ``FIELD_ALIASES``, ``TEMPORAL_FIELDS``) and inline
``field == "component"`` branches inside ``jql_engine``.

The registry encodes *what live Atlassian already does* as seen in traces, not
an invented schema:

- Every field the public contract already advertised stays known.
- Every field present in the synthetic issue data is registered and leveraged
  even if no current task queries it (e.g. ``story_points`` is backed by the
  ``story_points`` fixture column, so it stays). Fields with no synthetic-data
  mapping are intentionally omitted rather than advertised as empty: ``labels``
  (no fixture column) and ``resolution`` (a derived ``Resolved``/``Unresolved``
  value that does not match the real resolution picklist) were removed.
- Names *outside* the registry still raise the unknown-field error so invented
  fields fail loudly for the bench. That wording is mock-only (0 live hits).

Resolution lowercases the incoming token before lookup; aliases resolve to their
canonical ``FieldSpec``.
"""
from __future__ import annotations

from dataclasses import dataclass, field as dataclass_field
from typing import Literal


FieldKind = Literal["string", "list", "temporal", "number", "text"]


@dataclass(frozen=True)
class FieldSpec:
    """The typed policy for a single JQL field.

    ``kind`` drives how ``jql_engine`` dispatches a leaf comparison:
    string normalize, list membership, temporal day-boundary, numeric, or
    ``~`` text search.
    """

    name: str  # canonical lowercase key
    kind: FieldKind
    aliases: tuple[str, ...] = ()
    filterable: bool = True
    sortable: bool = True
    searchable: bool = False  # ``~`` only


_SPECS: tuple[FieldSpec, ...] = (
    # Identity / project
    FieldSpec("key", "string", aliases=("id", "issue")),
    FieldSpec("project", "string"),
    # Migrated source ID (ISS-xxx) preserved as the import-map field; the durable
    # cross-system correlation key. customfield_10001 is its alias.
    FieldSpec("external_id", "string", aliases=("customfield_10001",)),
    # Workflow
    FieldSpec("status", "string"),
    FieldSpec("statuscategory", "string"),
    FieldSpec("priority", "string"),
    FieldSpec("issuetype", "string", aliases=("type",)),
    # Structure
    FieldSpec("component", "list", aliases=("components",)),
    # Users
    FieldSpec("assignee", "string"),
    FieldSpec("reporter", "string"),
    FieldSpec("creator", "string"),
    # Text
    FieldSpec("summary", "text", searchable=True),
    FieldSpec("description", "text", searchable=True, filterable=False, sortable=False),
    FieldSpec("text", "text", searchable=True, filterable=False, sortable=False),
    # Temporal
    FieldSpec("created", "temporal"),
    FieldSpec("updated", "temporal"),
    FieldSpec("resolved", "temporal"),
    FieldSpec("resolutiondate", "temporal"),
    # Numeric
    FieldSpec("story_points", "number"),
)


def _build_index() -> dict[str, FieldSpec]:
    index: dict[str, FieldSpec] = {}
    for spec in _SPECS:
        index[spec.name] = spec
        for alias in spec.aliases:
            index[alias] = spec
    return index


_INDEX: dict[str, FieldSpec] = _build_index()


def lookup(token: str) -> FieldSpec | None:
    """Return the ``FieldSpec`` for a field token (case-insensitive), or ``None``
    when the name is not registered."""
    if not token:
        return None
    return _INDEX.get(token.lower())


def is_known(token: str) -> bool:
    """True when ``token`` (or one of its aliases) is registered."""
    return lookup(token) is not None


def canonical(token: str) -> str:
    """Resolve a token to its canonical field name, falling back to the
    lowercased token when unknown (callers gate on ``is_known`` first)."""
    spec = lookup(token)
    return spec.name if spec else (token.lower() if token else token)


# Convenience projections kept for callers that still want flat sets. Derived
# from the registry so there is a single source of truth.
KNOWN_FIELDS: frozenset[str] = frozenset(_INDEX)
CANONICAL_FIELDS: frozenset[str] = frozenset(spec.name for spec in _SPECS)
TEMPORAL_FIELDS: frozenset[str] = frozenset(
    spec.name for spec in _SPECS if spec.kind == "temporal"
)
LIST_FIELDS: frozenset[str] = frozenset(
    spec.name for spec in _SPECS if spec.kind == "list"
)
TEXT_FIELDS: frozenset[str] = frozenset(
    spec.name for spec in _SPECS if spec.searchable
)
ALIASES: dict[str, str] = {
    alias: spec.name for spec in _SPECS for alias in spec.aliases
}
