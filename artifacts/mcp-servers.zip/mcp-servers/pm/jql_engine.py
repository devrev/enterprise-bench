"""A validated, intentionally bounded JQL parser and evaluator for PM MCP v1.1."""
from __future__ import annotations

import importlib.util
import os
import re
import sys
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from typing import Any

import server as core


def _load_sibling(module_name: str):
    """Import a module that lives next to this file.

    Resolves whether we run from the Docker image (module dir on the working
    path) or are loaded by file spec in the unit-test harness (which does not
    add this dir to sys.path). Loading by explicit path also avoids any
    cross-service name collision when several services are tested in one
    process.
    """
    if module_name in sys.modules:
        return sys.modules[module_name]
    path = os.path.join(os.path.dirname(os.path.abspath(__file__)), f"{module_name}.py")
    spec = importlib.util.spec_from_file_location(module_name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[module_name] = module
    spec.loader.exec_module(module)
    return module


jql_fields = _load_sibling("jql_fields")
FieldSpec = jql_fields.FieldSpec

# The typed registry in ``jql_fields`` is the single source of truth for which
# fields exist and how each is compared. These names are projections of it,
# kept for readability at the call sites below.
FIELD_ALIASES = dict(jql_fields.ALIASES)
VALID_QUERY_FIELDS = jql_fields.KNOWN_FIELDS
TEMPORAL_FIELDS = jql_fields.TEMPORAL_FIELDS
LIST_FIELDS = jql_fields.LIST_FIELDS
TEXT_FIELDS = jql_fields.TEXT_FIELDS

UNBOUNDED_JQL_MESSAGE = (
    "Unbounded JQL queries are not allowed here. "
    "Please add a search restriction to your query."
)


class JQLParseError(ValueError):
    """Error whose message follows the JQL validation convention."""

    def __init__(self, message: str):
        super().__init__(f"Error in the JQL Query: {message}")


class UnboundedJQLError(ValueError):
    """Raised for syntactically valid JQL that carries no search restriction.

    The JQL parser parses ``ORDER BY`` with no preceding clause, then refuses to run it.
    """

    def __init__(self):
        super().__init__(UNBOUNDED_JQL_MESSAGE)


@dataclass(frozen=True)
class Literal:
    """A typed JQL scalar value preserved from the tokenizer."""

    kind: str
    text: str


@dataclass(frozen=True)
class TemporalValue:
    """UTC-normalized temporal literal or field value."""

    instant: datetime
    date_only: bool


@dataclass
class JQLQuery:
    where: Any = None
    order_by: list[tuple[str, str]] = field(default_factory=list)


_TOKEN = re.compile(
    r"\s*(?:(?P<string>'(?:\\.|[^'])*'|\"(?:\\.|[^\"])*\")|"
    r"(?P<date>\d{4}-\d{2}-\d{2})|(?P<number>\d+)|"
    r"(?P<operator>>=|<=|!=|=|>|<|~)|(?P<paren>[()])|(?P<comma>,)|"
    r"(?P<word>[A-Za-z_][A-Za-z0-9_]*(?:-[A-Za-z0-9_]+)*))"
)
_DATE_ONLY = re.compile(r"^\d{4}-\d{2}-\d{2}$")
_ISO_TIMESTAMP = re.compile(
    r"^\d{4}-\d{2}-\d{2}[T ]\d{2}:\d{2}(?::\d{2}(?:\.\d+)?)?"
    r"(?:Z|[+-]\d{2}:?\d{2})?$"
)


def _tokens(text: str) -> list[tuple[str, str]]:
    tokens, position = [], 0
    while position < len(text):
        match = _TOKEN.match(text, position)
        if not match:
            raise JQLParseError(f"unexpected token near {text[position:position + 24]!r}")
        position = match.end()
        kind = next(name for name, value in match.groupdict().items() if value is not None)
        value = match.group(kind)
        if kind == "string":
            value = value[1:-1].replace("\\'", "'").replace('\\"', '"')
        tokens.append((kind, value))
    return tokens


class _Parser:
    def __init__(self, text: str):
        self.items = _tokens(text)
        self.index = 0

    def _peek(self, value: str | None = None) -> bool:
        if self.index >= len(self.items):
            return False
        return value is None or self.items[self.index][1].upper() == value.upper()

    def _take(self, value: str | None = None) -> tuple[str, str]:
        if not self._peek(value):
            expected = value or "a JQL token"
            actual = "end of query" if self.index >= len(self.items) else self.items[self.index][1]
            raise JQLParseError(f"expecting {expected}, got {actual!r}")
        token = self.items[self.index]
        self.index += 1
        return token

    def parse(self) -> JQLQuery:
        if not self.items:
            raise JQLParseError("empty query")
        where = None if self._peek("ORDER") else self._or()
        order_by = []
        if self._peek("ORDER"):
            self._take("ORDER")
            self._take("BY")
            order_by = self._orders()
        if self.index != len(self.items):
            raise JQLParseError(f"unexpected token {self.items[self.index][1]!r}")
        return JQLQuery(where=where, order_by=order_by)

    def _or(self):
        node = self._and()
        children = [node]
        while self._peek("OR"):
            self._take("OR")
            children.append(self._and())
        return children[0] if len(children) == 1 else ("OR", children)

    def _and(self):
        node = self._primary()
        children = [node]
        while self._peek("AND"):
            self._take("AND")
            children.append(self._primary())
        return children[0] if len(children) == 1 else ("AND", children)

    def _primary(self):
        if self._peek() and self.items[self.index][0] == "paren" and self.items[self.index][1] == "(":
            self._take()
            node = self._or()
            self._take(")")
            return node
        return ("LEAF", self._predicate())

    def _value(self) -> Literal:
        kind, value = self._take()
        if kind not in {"word", "string", "date", "number"}:
            raise JQLParseError(f"expected a value, got {value!r}")
        return Literal(kind=kind, text=value)

    def _predicate(self) -> dict[str, Any]:
        kind, field = self._take()
        if kind != "word":
            raise JQLParseError(f"expected a field, got {field!r}")
        field = field.lower()
        if self._peek("IS"):
            self._take("IS")
            negate = self._peek("NOT")
            if negate:
                self._take("NOT")
            value = self._value().text.upper()
            if value not in {"EMPTY", "NULL"}:
                raise JQLParseError(f"expected EMPTY or NULL, got {value!r}")
            return {"type": "is_not_empty" if negate else "is_empty", "field": field}
        if self._peek("NOT"):
            self._take("NOT")
            self._take("IN")
            op = "not_in"
        elif self._peek("IN"):
            self._take("IN")
            op = "in"
        else:
            _, op = self._take()
            if op == "~":
                if field not in TEXT_FIELDS:
                    raise JQLParseError(f"operator '~' is not supported for field {field!r}")
                return {"type": "text_search", "field": field, "value": self._value().text}
            if op not in {"=", "!=", ">", "<", ">=", "<="}:
                raise JQLParseError(f"unsupported operator {op!r}")
            value = self._value()
            if value.text.upper() in {"EMPTY", "NULL"}:
                return {"type": "is_empty" if op == "=" else "is_not_empty", "field": field}
            if _canonical_field(field) in TEMPORAL_FIELDS:
                _parse_temporal(value, required=True)
            return {
                "type": "eq" if op == "=" else "neq" if op == "!=" else "cmp",
                "field": field,
                "op": op,
                "value": value.text,
                "value_kind": value.kind,
            }
        self._take("(")
        values = [self._value()]
        while self._peek() and self.items[self.index][0] == "comma":
            self._take()
            values.append(self._value())
        self._take(")")
        return {
            "type": op,
            "field": field,
            "values": [item.text for item in values],
            "value_kinds": [item.kind for item in values],
        }

    def _orders(self) -> list[tuple[str, str]]:
        orders = []
        while True:
            _, field = self._take()
            direction = "ASC"
            if self._peek("ASC") or self._peek("DESC"):
                direction = self._take()[1].upper()
            orders.append((field.lower(), direction))
            if not (self._peek() and self.items[self.index][0] == "comma"):
                return orders
            self._take()


def _parse_jql(jql: str):
    query = _Parser(jql).parse()
    return query.where, query.order_by


def _canonical_field(field: str) -> str:
    return jql_fields.canonical(field)


def _norm_token(value: Any) -> str:
    """Casefold and treat underscores as spaces so stored snake_case values
    (e.g. ``in_progress``) match PM display forms (e.g. ``"In Progress"``)."""
    return re.sub(r"[\s_]+", " ", str(value).strip().lower())


def _field_error(field: str) -> ValueError:
    return ValueError(f"Field '{field}' does not exist or you do not have permission to view it.")


def _to_utc(value: datetime) -> datetime:
    if value.tzinfo is None:
        return value.replace(tzinfo=timezone.utc)
    return value.astimezone(timezone.utc)


def _parse_temporal(value: Any, *, required: bool = False) -> TemporalValue | None:
    """Normalize a literal or field value to a UTC datetime.

    Date-only values become midnight UTC with ``date_only=True``. Full timestamps
    (with optional ``Z`` / offset) become aware UTC instants. Non-temporal text
    returns ``None`` unless ``required`` is set, in which case a JQL error is raised.
    """
    if isinstance(value, Literal):
        kind, text = value.kind, value.text
    elif isinstance(value, TemporalValue):
        return value
    elif isinstance(value, datetime):
        return TemporalValue(instant=_to_utc(value), date_only=False)
    else:
        kind, text = "string", "" if value is None else str(value).strip()

    if not text:
        if required:
            raise JQLParseError("Date value '' is invalid")
        return None

    if kind == "date" or _DATE_ONLY.fullmatch(text):
        try:
            day = datetime.strptime(text, "%Y-%m-%d").replace(tzinfo=timezone.utc)
        except ValueError as error:
            if required or kind == "date":
                raise JQLParseError(f"Date value '{text}' is invalid") from error
            return None
        return TemporalValue(instant=day, date_only=True)

    if _ISO_TIMESTAMP.fullmatch(text):
        normalized = text.replace(" ", "T")
        if normalized.endswith("Z"):
            normalized = normalized[:-1] + "+00:00"
        elif re.search(r"[+-]\d{4}$", normalized):
            normalized = f"{normalized[:-5]}{normalized[-5:-2]}:{normalized[-2:]}"
        try:
            parsed = datetime.fromisoformat(normalized)
        except ValueError as error:
            if required:
                raise JQLParseError(f"Date value '{text}' is invalid") from error
            return None
        return TemporalValue(instant=_to_utc(parsed), date_only=False)

    if required:
        raise JQLParseError(f"Date value '{text}' is invalid")
    return None


def _compare_temporal(actual: TemporalValue, op: str, expected: TemporalValue) -> bool:
    """Apply date-only day-boundary semantics or exact instant comparison."""
    left = actual.instant
    if expected.date_only:
        start = expected.instant
        end = start + timedelta(days=1)
        if op == "=":
            return start <= left < end
        if op == "!=":
            return not (start <= left < end)
        if op == ">=":
            return left >= start
        if op == ">":
            return left >= end
        if op == "<=":
            return left < end
        if op == "<":
            return left < start
        raise JQLParseError(f"unsupported operator {op!r}")
    right = expected.instant
    return {">": left > right, "<": left < right, ">=": left >= right, "<=": left <= right, "=": left == right, "!=": left != right}[op]


def _query_field_value(issue: dict, field: str) -> Any:
    field = _canonical_field(field)
    if field == "key":
        # v2: the native key is the opaque project-scoped MPL key.
        return issue.get("pm_key", issue.get("issue_id", ""))
    if field == "external_id":
        # Migrated source ID (ISS-xxx), the durable cross-system correlation key.
        # customfield_10001 aliases to this field (see jql_fields).
        return issue.get("external_id", issue.get("issue_id", ""))
    if field == "statuscategory":
        status = issue.get("status", "").lower()
        return "Done" if status == "done" else "In Progress" if status == "in_progress" else "To Do"
    if field == "resolutiondate":
        return issue.get("resolved_at")
    return core._query_field_value(issue, field)


def _list_values(issue: dict, field: str) -> list[str]:
    """Return a JQL ``list`` field's membership values as a flat list of strings.

    ``component`` reads the raw fixture key. Any future ``list`` field shares
    List semantics from here on.
    """
    if field == "component":
        return list(issue.get("components", []))
    value = _query_field_value(issue, field)
    return list(value) if value else []


def _leaf_matches(issue: dict, condition: dict[str, Any]) -> bool:
    field, kind = condition.get("field", ""), condition["type"]
    spec: FieldSpec | None = jql_fields.lookup(field) if field else None
    if field and spec is None:
        raise _field_error(field)
    field = _canonical_field(field)
    if kind == "text_search":
        value = condition["value"].lower()
        title, description = issue.get("title", "").lower(), issue.get("description", "").lower()
        return value in title if field == "summary" else value in description if field == "description" else value in title or value in description

    is_list = spec is not None and spec.kind == "list"
    if is_list:
        members = {_norm_token(item) for item in _list_values(issue, field)}
        if kind == "is_empty":
            return not members
        if kind == "is_not_empty":
            return bool(members)
        # Null semantics: a null/empty field is excluded from value
        # comparisons entirely — =, !=, IN, and NOT IN all fail to match on an
        # empty list. Only IS EMPTY matches it.
        if not members:
            return False
        if kind == "in":
            return any(_norm_token(value) in members for value in condition["values"])
        if kind == "not_in":
            return not any(_norm_token(value) in members for value in condition["values"])
        if kind == "eq":
            return _norm_token(condition["value"]) in members
        if kind == "neq":
            return _norm_token(condition["value"]) not in members
        # No ordered comparison for list fields; treat as non-match.
        return False

    actual = _query_field_value(issue, field)
    if kind == "is_empty":
        return actual is None or actual == ""
    if kind == "is_not_empty":
        return actual is not None and actual != ""
    if kind in {"in", "not_in"}:
        found = _norm_token(actual) in {_norm_token(value) for value in condition["values"]}
        return not found if kind == "not_in" else found
    if actual is None or actual == "":
        return False

    literal = Literal(kind=condition.get("value_kind", "string"), text=str(condition["value"]))
    if field in TEMPORAL_FIELDS:
        left = _parse_temporal(actual, required=True)
        right = _parse_temporal(literal, required=True)
        assert left is not None and right is not None
        op = "=" if kind == "eq" else "!=" if kind == "neq" else condition["op"]
        return _compare_temporal(left, op, right)

    if kind == "eq":
        return _norm_token(actual) == _norm_token(condition["value"])
    if kind == "neq":
        return _norm_token(actual) != _norm_token(condition["value"])
    try:
        left, right = float(actual), float(condition["value"])
    except (ValueError, TypeError):
        left, right = str(actual), condition["value"]
    return {">": left > right, "<": left < right, ">=": left >= right, "<=": left <= right}[condition["op"]]


def _issue_matches_query(issue: dict, tree) -> bool:
    kind, body = tree
    if kind == "LEAF":
        return _leaf_matches(issue, body)
    values = [_issue_matches_query(issue, child) for child in body]
    return all(values) if kind == "AND" else any(values)


def search(jql: str, start_at: int, max_results: int):
    tree, order = _parse_jql(jql)
    if tree is None:
        raise UnboundedJQLError()
    rows = [row for row in core.ISSUES.values() if _issue_matches_query(row, tree)]
    for field, direction in reversed(order):
        rows.sort(key=lambda row: (_query_field_value(row, field) is None, _query_field_value(row, field) or ""), reverse=direction == "DESC")
    return rows, len(rows), start_at, max_results
