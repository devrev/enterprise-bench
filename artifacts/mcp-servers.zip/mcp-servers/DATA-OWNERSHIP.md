# MCP data ownership

Each server reads **only its own data folder**. No server reads another's folder:
*clone the files and each server reads only from its own folder.*

## Owner folders (scale-specific data under the data root)

| Server | Reads from | Files |
|-----|-----------|-------|
| CRM (`crm`) | `crm_json_data/` | `accounts.json`, `opportunities.json`, `tickets.json`, `users.json` |
| PM (`pm`) | `pm_json_data/` | `comments.json`, `conversations.json`, `issues.json`, `maple_parts.json`, `users.json` |
| CS (`cs`) | `cs_json_data/` | `accounts.json`, `users.json`, `tickets.json`, `comments.json`, `conversations.json` |

## Owner folders (shared data at the data root — not scale-specific)

| MCP | Reads from | Files |
|-----|-----------|-------|
| Mail (`mail-server`) | `email_json_data/` | `messages.json`, `labels.json`, `attachments.json` |
| Calendar (`calendar-server`) | `calendar_json_data/` | `events.json`, `transcripts.json` |

## Why CS has its own folder

Earlier, the CS server (a Zendesk-style mock) read shared files out of
`crm_json_data/` (`tickets.json`, `accounts.json`, `users.json`) and `pm_json_data/`
(`comments.json`, `conversations.json`). That cross-reading coupled three systems to
two folders. Those files are now **cloned** into `cs_json_data/` and the CS server
reads only from there.

## Cloned files and the divergence risk

The clones are **point-in-time copies** and must stay byte-identical to
their owner sources:

| `cs_json_data/` file | Owner source |
|----------------------|--------------|
| `tickets.json` | `crm_json_data/tickets.json` |
| `accounts.json` | `crm_json_data/accounts.json` |
| `users.json` | `crm_json_data/users.json` |
| `comments.json` | `pm_json_data/comments.json` |
| `conversations.json` | `pm_json_data/conversations.json` |

Accepted risk: editing an owner file without re-cloning to `cs_json_data/` (or vice
versa) causes inconsistent data. To re-sync after an intentional owner change, re-copy
the five files into `cs_json_data/`.

## Future

Realistic intentional divergence (e.g. CS-only users that never existed in CRM) and a
federated identity register are planned. Until then the clones are kept identical.
