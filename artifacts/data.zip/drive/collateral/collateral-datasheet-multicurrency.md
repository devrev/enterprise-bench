# Maple Multi-Currency — Product Data Sheet

> One-page product data sheet (spec-08 §4.4). Generic capability summary — no account
data. Any service-level references follow Maple's published tier terms, not this sheet.

## Maple Multi-Currency
Maple Multi-Currency is a capability of the Maple Payments Platform. Maple consolidates the payment lifecycle onto a single platform — processing, fraud prevention with Maple Shield, hosted and API-based checkout, multi-currency support, and settlement/reconciliation. Because these capabilities share one data model, teams get consistent reporting and fewer reconciliation gaps than a stitched-together stack.

## Overview
The payments landscape continues to fragment across regions, methods, and regulatory regimes. Merchants selling across borders must present locally trusted payment methods, meet Strong Customer Authentication (SCA) requirements, and reconcile settlement across currencies — all while keeping authorization rates high and fraud losses low. Vendor sprawl compounds the problem: each additional processor, fraud tool, and reconciliation system adds integration overhead and operational blind spots.

Maple Multi-Currency helps teams address these pressures as part of a unified platform, avoiding the
integration overhead of assembling separate point tools.

## Key capabilities
- Production-grade reliability and predictable performance.
- Region-aware behavior and localized presentment where applicable.
- Developer-friendly integration via REST APIs and webhook events.
- Built-in fraud prevention through Maple Shield.
- Consistent reporting that reconciles cleanly with settlement.

## Integration
- REST API and webhook-driven event model.
- Hosted options where PCI scope reduction is required.
- Production-parity sandbox with test cards for evaluation.
- SDKs and clear documentation to shorten time to first transaction.

## Operational benefits
- Fewer vendors to manage and reconcile.
- A single transaction view for operations and finance teams.
- Faster financial close through consistent settlement reporting.

## Security and compliance
- PCI DSS Level 1.
- SOC 2 Type II.
- GDPR-aligned data handling.

## Use cases
- Merchants consolidating multiple point tools onto a single platform.
- Teams expanding into new regions that need localized payment behavior.
- Finance organizations seeking cleaner settlement and faster close.
- Engineering teams that want fewer integrations to build and maintain.

## What sets it apart
Unlike bolt-on point solutions, Maple Multi-Currency shares Maple's common data model, so the data an
agent, analyst, or finance user sees is consistent across checkout, fraud, and settlement.
That consistency is what removes the reconciliation gaps that fragmented stacks create, and
it is the reason teams report less operational overhead after consolidating.

## Getting started
Teams typically begin in the sandbox, validate parity against current behavior, then enable
Maple Multi-Currency for a limited segment before expanding. Service-level commitments are governed by
the customer's contracted tier and the applicable service agreement. Documentation, SDKs, and
sample integrations shorten the path from evaluation to first live transaction.

## Frequently asked questions
**Can we evaluate before committing?** Yes — a production-parity sandbox is available.
**Does it require replacing our whole stack?** No — most teams adopt incrementally.
**How are updates handled?** Platform updates are managed by Maple with backward-compatible
APIs wherever possible.

[Maple logo] | maple.io | sales@maple.io

Learn more at maple.io or contact your Maple representative.
