# Mutual Non-Disclosure Agreement

**Between:** Maple Payments, Inc. and Nexus Logistics
**Effective Date:** March 3, 2024
**Governing Law:** State of Delaware, USA

## 1. Purpose
The parties wish to explore a potential business relationship and, in connection with this,
may disclose Confidential Information to one another.

## 2. Confidential Information
"Confidential Information" means any non-public information disclosed by one party to the
other, whether orally, in writing, or by inspection of tangible objects, that is designated
as confidential or that reasonably should be understood to be confidential.

## 3. Obligations
Each party agrees to (a) hold the other's Confidential Information in strict confidence,
(b) not disclose it to third parties without prior written consent, and (c) use it solely
for the Purpose stated above.

## 4. Term
The obligations of confidentiality survive for three (3) years from the date of disclosure.

## 5. General
This Agreement is governed by the laws of State of Delaware, USA. Nothing herein obligates either
party to proceed with any transaction.

## 6. Exclusions
Confidential Information does not include information that: (a) is or becomes publicly
available through no breach of this Agreement; (b) was rightfully known to the receiving
party before disclosure; (c) is rightfully received from a third party without a duty of
confidentiality; or (d) is independently developed without use of the disclosing party's
Confidential Information.

## 7. Return or Destruction
Upon written request or termination of discussions, each party shall promptly return or
destroy the other party's Confidential Information, retaining no copies except as required
by law or routine backup procedures, subject to continuing confidentiality obligations.

## 8. No License
Nothing in this Agreement grants either party any license or right, by implication or
otherwise, to any intellectual property of the other party, except the limited right to use
Confidential Information solely for the Purpose.

## 9. Remedies
The parties acknowledge that unauthorized disclosure may cause irreparable harm for which
monetary damages would be an inadequate remedy, and that the disclosing party is entitled to
seek injunctive relief in addition to any other remedies available at law or equity.

## 10. Entire Agreement
This Agreement constitutes the entire understanding between the parties regarding its subject
matter and supersedes all prior discussions. Any amendment must be in writing and signed by
both parties.

*Standard mutual NDA template. No account-specific commercial terms.*
